-- Top 5 GM-approved project requests per Business Unit, by score. Read-only; one result grid (pgAdmin).
-- Business Unit = the business unit of the requesting unit (climbs from a department), as the dashboards do.
-- Ranking: Scalability Score, then Project Score; unscored requests sort last.
-- Excludes requests later REJECTED or CANCELLED.

WITH RECURSIVE climb AS (
    -- Walk from each request's requesting unit up to its Business Unit.
    SELECT wr.id AS work_request_id, ou.id AS unit_id, ou.type::text AS unit_type, ou.parent_id
    FROM work_requests wr
    JOIN organisation_units ou ON ou.id = wr.requesting_organisation_unit_id
    WHERE wr.gm_approved_at IS NOT NULL
      AND wr.request_status::text NOT IN ('REJECTED', 'CANCELLED')
    UNION ALL
    SELECT c.work_request_id, p.id, p.type::text, p.parent_id
    FROM climb c
    JOIN organisation_units p ON p.id = c.parent_id
    WHERE c.unit_type <> 'BUSINESS_UNIT'
),
bu AS (
    SELECT work_request_id, unit_id AS business_unit_id
    FROM climb
    WHERE unit_type = 'BUSINESS_UNIT'
),
ranked AS (
    SELECT wr.*, bu.business_unit_id,
           ROW_NUMBER() OVER (
               PARTITION BY bu.business_unit_id
               ORDER BY wr.scalability_score DESC NULLS LAST, wr.project_score DESC NULLS LAST, wr.gm_approved_at
           ) AS rank_in_bu
    FROM work_requests wr
    JOIN bu ON bu.work_request_id = wr.id
)
SELECT
    b.name                                   AS "Business Unit",
    r.rank_in_bu                             AS "Rank",
    r.request_no                             AS "Request No",
    COALESCE(pr.project_name, r.project_name) AS "Project Name",
    r.problem_statement                      AS "Problem",
    r.problem_measurement                    AS "Measure of the Problem",
    r.objectives                             AS "Objective",
    array_to_string(r.project_categories::text[], ', ')
        || CASE WHEN r.project_category_other IS NOT NULL THEN ' (' || r.project_category_other || ')' ELSE '' END
                                             AS "Categories",
    COALESCE(
        (SELECT string_agg(t.name, ', ' ORDER BY t.name)
         FROM work_request_pain_point_tags wpt JOIN pain_point_tags t ON t.id = wpt.pain_point_tag_id
         WHERE wpt.work_request_id = r.id),
        array_to_string(r.pain_point_tags, ', '))
                                             AS "Pain Points",
    COALESCE(lob.name, bp.name)              AS "Line of Business",
    r.complexity_score                       AS "Complexity",
    r.annual_cost_saving_score               AS "Annual Cost Saving",
    r.capex_required_score                   AS "CAPEX Required",
    r.pain_point_frequency_score             AS "Pain Point Frequency",
    CASE r.scalability
        WHEN 1 THEN 'Not applicable (x1.0)'
        WHEN 2 THEN 'As a product (x1.0)'
        WHEN 3 THEN 'Within the Business Unit (x1.0)'
        WHEN 4 THEN 'Across Business Units (x1.2)'
        WHEN 5 THEN 'Across Line of Business (x1.5)'
        WHEN 6 THEN 'Across Business Area (x2.0)'
    END                                      AS "Scalability",
    r.project_score                          AS "Project Score",
    r.scalability_score                      AS "Scalability Score",
    r.currency_code                          AS "Currency",
    r.total_annual_saving                    AS "Estimated Cost Savings",
    (SELECT string_agg(a.category || ' ' || a.percentage || '% (' || a.amount || ')', '; ' ORDER BY a.category)
     FROM work_request_benefit_allocations a
     WHERE a.work_request_id = r.id AND a.allocation_type = 'COST_SAVINGS')
                                             AS "Savings Allocation",
    r.potential_cost_avoidance               AS "Cost Avoidance",
    (SELECT string_agg(a.category || ' ' || a.percentage || '% (' || a.amount || ')', '; ' ORDER BY a.category)
     FROM work_request_benefit_allocations a
     WHERE a.work_request_id = r.id AND a.allocation_type = 'COST_AVOIDANCE')
                                             AS "Avoidance Allocation",
    r.potential_revenue                      AS "Potential Revenue",
    CASE WHEN pr.id IS NOT NULL THEN 'Project: ' || pr.status::text
         ELSE 'Request: ' || r.request_status::text || ' / ' || r.approval_stage::text
    END                                      AS "Current Status",
    COALESCE(hod.full_name, hod_planned.full_name) AS "HOD",
    COALESCE(gm.full_name, gm_planned.full_name)   AS "GM",
    (SELECT string_agg(s.name
                       || COALESCE(' - ' || NULLIF(s.appointment, ''), '')
                       || COALESCE(' (' || NULLIF(s.project_role, '') || ')', ''),
                       '; ' ORDER BY s.stakeholder_no)
     FROM request_stakeholders s WHERE s.work_request_id = r.id)
                                             AS "Stakeholders"
FROM ranked r
JOIN organisation_units b       ON b.id = r.business_unit_id
LEFT JOIN organisation_units bp ON bp.id = b.parent_id AND bp.type::text = 'LINE_OF_BUSINESS'  -- primary line
LEFT JOIN organisation_units lob ON lob.id = r.line_of_business_id                            -- line chosen on the request
LEFT JOIN projects pr           ON pr.source_request_id = r.id
LEFT JOIN users hod             ON hod.id = r.hod_approved_by_user_id
LEFT JOIN users hod_planned     ON hod_planned.id = r.hod_approver_user_id
LEFT JOIN users gm              ON gm.id = r.gm_approved_by_user_id
LEFT JOIN users gm_planned      ON gm_planned.id = r.gm_approver_user_id
WHERE r.rank_in_bu <= 5
ORDER BY b.name, r.rank_in_bu;
