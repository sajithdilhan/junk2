# HOD endorsement: the three delivery options

## Summary

In the current flow, all three options end up in the same place. Whichever option the HOD picks, the request goes through GM approval, then the Steering Committee (only if it's escalated), then GM routing, and then waits at **Awaiting Initialisation**. At that point the assigned HOD initialises it, and that creates the project. The option only changes two things: what's recorded about the start, and what's pre-filled on the initialisation form.

## Comparison

| | **Add to approved list** | **Assign now — I'll name the team and lead** | **Awaiting assignment — start now** |
|---|---|---|---|
| Stored as | `BACKLOG` (lead optional) | `START_NOW` with department, team and lead | `START_NOW`, no team or lead |
| What the HOD fills in | Optionally a proposed lead. A team or department is rejected. | Department, team and lead (all three required), plus governance flags | Nothing. Governance flags are rejected. |
| Next steps | GM approval → Steering Committee if escalated → GM routing → initialisation | Same | Same |
| Where it ends up | **Awaiting Initialisation** | **Awaiting Initialisation** | **Awaiting Initialisation** |
| Who acts at the end | The assigned HOD: the HOD named on the request (internal route), or the HOD of the external department the GM routed it to. A Super Admin can step in. | Same | Same |
| Where that person sees it | My approvals → **To initialise** tab (counted in the nav badge), and Projects → **Pending Initialisation** | Same | Same |
| Initialisation form | Opens empty except for the proposed lead, if one was given | Opens pre-filled with the department, team and lead, if those are still assignable for this HOD | Opens empty |
| When the project is created | When the assigned HOD initialises it (status Not Started) | Same | Same |
| Where the choice is shown | The approval trail on the request detail page | Same | Same |

For an external route, the assign-now pre-fill usually won't apply. The external HOD can only deliver within their own business unit, so the team the endorsing HOD picked is normally not one they can assign.

## The descriptions on screen are out of date

The descriptions under each option were written for an older flow and no longer match what happens:

1. **Assign now** says "the project is created as soon as you confirm." Today that only happens for old requests that have no approval stages. For any current request, the project is still created at initialisation, after GM routing.
2. **Awaiting assignment** says it "goes to the department's awaiting-assignment queue, and the manager who picks it up names the team." No such queue appears anywhere in the app. The `project-backlog` API still exists, but no page calls it, and the Projects page's "Approved List" tab was removed. The request simply goes to the assigned HOD's To initialise list, like the other two options.
3. **Add to approved list** says "it joins the approved list." There's no approved list page either. It goes to the same To initialise list.
4. **Nothing marks a "start now" request as urgent.** The To initialise and Pending Initialisation lists show a backlog request and a start-now request the same way. The difference is only visible in the approval trail on the request itself.
5. `docs/product/terminology.md` (lines 925–927) still says the two are told apart on the Projects page's "Approved List" tab, which no longer exists.

In practice, the only real difference between the three options is whether the initialisation form opens pre-filled.

## Options

- **Small fix:** rewrite the three descriptions to match the actual flow, and correct the terminology doc. This is a copy change only.
- **Bigger fix:** make the difference visible, for example a "Start now" or "Approved list" chip on the To initialise and Pending Initialisation rows. Or decide whether three options are still needed at all. This one changes product behaviour, so it needs a product decision first.

## Sources

- `apps/web/src/app/features/work-requests/utils/work-request-detail.constants.ts`: option labels and descriptions
- `apps/web/src/app/features/work-requests/utils/work-request-decision.utils.ts`: how each option maps to what the API receives
- `apps/api-dotnet/src/ProjectRepository.Application/WorkRequests/Policies/WorkRequestDeliveryPolicy.cs`: validation for each option
- `apps/api-dotnet/src/ProjectRepository.Application/WorkRequests/Commands/UpdateWorkRequestStatus/UpdateWorkRequestStatusCommandHandler.cs`: project created on approval only for requests with no approval stages
- `apps/api-dotnet/src/ProjectRepository.Domain/WorkRequests/Services/WorkRequestQueue.cs`: who has to initialise
- `apps/web/src/app/features/approvals/utils/approvals.constants.ts` and `apps/web/src/app/features/project-view/utils/project-view.constants.ts`: where the requests are listed