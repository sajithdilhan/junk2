-- Delete every milestone and task on ONE UAT project (test data only). No audit rows.
-- pgAdmin: set the project code in all four places marked <<< below, run the whole script,
-- check the counts in the result grid, then run COMMIT; (or ROLLBACK; to undo).

BEGIN;

-- 1. Activity-feed entries that point at those milestones/tasks
--    (FK is SET NULL, so without this they would stay in the feed as orphan entries).
DELETE FROM project_activity a
USING projects p
WHERE a.project_id = p.id
  AND p.project_code = 'PRJ-XXXX-XXXXX'   -- <<< project code
  AND (a.milestone_id IS NOT NULL OR a.task_id IS NOT NULL);

-- 2. Tasks (assignees and task updates cascade). One statement, so the
--    prerequisite FK between tasks on the same milestone is satisfied.
DELETE FROM project_timeline_tasks t
USING project_timelines tl, projects p
WHERE t.timeline_id = tl.id
  AND tl.project_id = p.id
  AND p.project_code = 'PRJ-XXXX-XXXXX';  -- <<< project code

-- 3. Milestones.
DELETE FROM project_milestones m
USING projects p
WHERE m.project_id = p.id
  AND p.project_code = 'PRJ-XXXX-XXXXX';  -- <<< project code

-- Check: all four counts should be 0.
SELECT p.project_code,
       (SELECT count(*) FROM project_milestones m WHERE m.project_id = p.id) AS milestones_left,
       (SELECT count(*) FROM project_timeline_tasks t JOIN project_timelines tl ON tl.id = t.timeline_id
         WHERE tl.project_id = p.id) AS tasks_left,
       (SELECT count(*) FROM project_activity a WHERE a.project_id = p.id
         AND (a.milestone_id IS NOT NULL OR a.task_id IS NOT NULL)) AS linked_activity_left
FROM projects p
WHERE p.project_code = 'PRJ-XXXX-XXXXX';  -- <<< project code

-- Then run ONE of:
-- COMMIT;
-- ROLLBACK;
